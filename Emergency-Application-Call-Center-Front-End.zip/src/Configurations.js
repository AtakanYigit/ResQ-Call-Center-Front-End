const Configurations = {
    signIn: "http://localhost:5000/api/v1/auth/signin",
    forgotPassword: "http://localhost:5000/api/v1/auth/forgotPassword",
    logout: "http://localhost:5000/api/v1/auth/logout",
}

export default Configurations;